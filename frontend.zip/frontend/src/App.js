import React, { useState } from 'react';
import { Line, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';
import './App.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend
);

const speciesList = [
  {
    name: 'Saltwater Crocodile',
    image: 'https://res.cloudinary.com/roundglass/image/upload/v1599135460/roundglass/sustain/sundarbans-saltwater-crocodile-crop-arindam-bhattacharya-2_gpis3m.jpg',
    data: {
      populationTrend: [150, 155, 160, 165, 170],
      biodiversityIndex: 0.78,
      mangroveHealth: 'At Risk',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Mangrove Jack',
    image: 'https://oceandreamcharters.com.au/wp-content/uploads/2018/05/Mangrove-Jack.jpg.webp', 
    data: {
      populationTrend: [500, 520, 530, 550, 600],
      biodiversityIndex: 0.85,
      mangroveHealth: 'Good',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Dugongs',
    image: 'https://th-thumbnailer.cdn-si-edu.com/p2LfzI_660oCFbzYFP2uDO-MFSc=/1000x750/filters:no_upscale():focal(2688x2022:2689x2023)/https://tf-cmsv2-smithsonianmag-media.s3.amazonaws.com/filer_public/a9/48/a9486d72-2527-43f1-8fe2-7eeef50bb800/mar2024_b01_heroesofthewilddugong.jpg', 
    data: {
      populationTrend: [20, 22, 25, 28, 30],
      biodiversityIndex: 0.9,
      mangroveHealth: 'Healthy',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Mudskipper',
    image: 'https://www.aquariumbcn.com/wp-content/uploads/2022/08/Periophthalmus-barbarus_1-1536x1024.jpg',  
    data: {
      populationTrend: [100, 110, 120, 130, 140],
      biodiversityIndex: 0.72,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Green Sea Turtle',
    image: 'https://viecotours.com/wp-content/uploads/sites/3785/2024/09/VI-Ecotours-Blog-sea-turtle-in-grass.png?w=1000&h=1000',  
    data: {
      populationTrend: [50, 55, 60, 65, 70],
      biodiversityIndex: 0.8,
      mangroveHealth: 'Good',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Great Egret',
    image: 'https://i0.wp.com/paddleandtrails.com/wp-content/uploads/2023/07/Florida-Great-Egret-WM.jpg?resize=685%2C428&ssl=1',  
    data: {
      populationTrend: [200, 210, 220, 230, 240],
      biodiversityIndex: 0.87,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Dolphins',
    image: 'https://www.captainjacksairboattours.com/wp-content/uploads/2024/03/iStock-511803551-1-gf_1.jpg', 
    data: {
      populationTrend: [30, 35, 40, 45, 50],
      biodiversityIndex: 0.92,
      mangroveHealth: 'Healthy',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Red Mangrove',
    image: 'https://m.media-amazon.com/images/I/61rGFr8xsQL._AC_UF894,1000_QL80_.jpg',  
    data: {
      populationTrend: [1000, 1020, 1040, 1060, 1080],
      biodiversityIndex: 0.95,
      mangroveHealth: 'Thriving',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Nitrogen-fixing Bacteria',
    image: 'https://milnepublishing.geneseo.edu/app/uploads/sites/235/2020/06/image1-32.jpeg',  
    data: {
      populationTrend: [5000, 5100, 5200, 5300, 5400],
      biodiversityIndex: 0.9,
      mangroveHealth: 'Critical',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Fiddler Crab',
    image: 'https://scaquarium.org/wp-content/uploads/2015/11/sc-aquarium-fiddler-crab-animal-spec-sheet.jpg',  
    data: {
      populationTrend: [120, 130, 140, 150, 160],
      biodiversityIndex: 0.75,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Mangrove Oyster',
    image: 'https://i.seadn.io/gae/vRzX3hlVKVq-92n7Qvu_KurQM1DuD8gHGaT7f9AnIWBn0W00aQ4HNNlF2l7Lza9cqx7Zl-NWgr70R23dgfmwC3fypKjaXjIHGnHsZMY?auto=format&dpr=1&w=1400&fr=1',  
    data: {
      populationTrend: [300, 310, 320, 330, 340],
      biodiversityIndex: 0.78,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Monitor Lizard',
    image: 'https://preview.redd.it/nl5p7b60aex51.jpg?width=640&crop=smart&auto=webp&s=bae3a6c592a9bdb856ec812ebd5a3e6a890df3ba',  
    data: {
      populationTrend: [50, 55, 60, 65, 70],
      biodiversityIndex: 0.82,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Mangrove Tree Frog',
    image: 'https://www.researchgate.net/publication/259632374/figure/fig8/AS:267826732728334@1440866277320/Mangrove-Frog-Fejervarya-cancrivora-resting-on-mangrove-root.png',  
    data: {
      populationTrend: [30, 35, 40, 45, 50],
      biodiversityIndex: 0.7,
      mangroveHealth: 'Good',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Kingfisher',
    image: 'https://base-prod.rspb-prod.magnolia-platform.com/dam/jcr:542411e9-8047-450b-829d-7995048ac27e/1680461044-Species-Kingfisher-perched-on-reed-bullrush.jpg',  
    data: {
      populationTrend: [80, 85, 90, 95, 100],
      biodiversityIndex: 0.88,
      mangroveHealth: 'Healthy',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Wild Boar',
    image: 'https://lamont.columbia.edu/sites/default/files/styles/cu_crop/public/cu_ldeo_news_import/96578/4.9boar-637x425.jpeg?itok=uSZdFHmU',  
    data: {
      populationTrend: [40, 45, 50, 55, 60],
      biodiversityIndex: 0.86,
      mangroveHealth: 'Stable',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Red-tailed Tropicbird',
    image: 'https://upload.wikimedia.org/wikipedia/commons/4/47/Red-tailed_Tropicbird_RWD2.jpg',  
    data: {
      populationTrend: [90, 95, 100, 105, 110],
      biodiversityIndex: 0.84,
      mangroveHealth: 'Good',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Binturong',
    image: 'https://animals.sandiegozoo.org/sites/default/files/inline-images/binterong_02.jpg',  
    data: {
      populationTrend: [20, 25, 30, 35, 40],
      biodiversityIndex: 0.89,
      mangroveHealth: 'At Risk',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'Mangrove Ant',
    image: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgaiK3wqK4Sxs6XBhSFvXkssXQWtHQlpi8Mh_rIIccvyKT_xml3G9NjsUzSwgJuAiYuGksM9Vswfs2lvHNCgcnu8fbMxyQeUDc0iBCZ2lI9abvDb4-n0nB3pkZPjsHk5oslqPnbE-545ioB/s1600/MangroveAnt.jpg',  
    data: {
      populationTrend: [500, 520, 540, 560, 580],
      biodiversityIndex: 0.74,
      mangroveHealth: 'Critical',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  {
    name: 'White Mangrove',
    image: 'https://envirodiva.wordpress.com/wp-content/uploads/2011/08/red-mangrove-swamp-2.jpg',  
    data: {
      populationTrend: [1200, 1250, 1300, 1350, 1400],
      biodiversityIndex: 0.96,
      mangroveHealth: 'Thriving',
      years: [2018, 2019, 2020, 2021, 2022],
    },
  },
  
];


function App() {
  const [selectedSpecies, setSelectedSpecies] = useState(null);

  const handleSpeciesClick = (species) => {
    setSelectedSpecies(species);
  };

  return (
    <div className="App">
      <h1>Mangrove AI</h1>
      <div className="species-gallery">
        {speciesList.map((species, index) => (
          <div
            key={index}
            className="species-card"
            onClick={() => handleSpeciesClick(species)}
          >
            <img src={species.image} alt={species.name} />
            <p>{species.name}</p>
          </div>
        ))}
      </div>
      {selectedSpecies && (
        <div className="charts-container">
          <h2>Data for {selectedSpecies.name}</h2>
          <div className="charts">
            <div className="line-chart">
              <h3>Population Trend Over Years</h3>
              <Line
                data={{
                  labels: selectedSpecies.data.years,
                  datasets: [
                    {
                      label: 'Population',
                      data: selectedSpecies.data.populationTrend,
                      borderColor: 'blue',
                      backgroundColor: 'rgba(0, 123, 255, 0.2)',
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                }}
              />
            </div>
            <div className="pie-chart">
              <h3>Biodiversity Index</h3>
              <Pie
                data={{
                  labels: ['Biodiversity Index', 'Remaining'],
                  datasets: [
                    {
                      data: [
                        selectedSpecies.data.biodiversityIndex * 100,
                        100 - selectedSpecies.data.biodiversityIndex * 100,
                      ],
                      backgroundColor: ['#28a745', '#dc3545'],
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      position: 'top',
                      labels: {
                        font: {
                          size: 12,
                        },
                      },
                    },
                  },
                }}
              />
            </div>
          </div>
          <div className="health-info">
            <h3>Mangrove Health Condition</h3>
            <p style={{ fontSize: '18px', color: 'darkblue' }}>
              <strong>{selectedSpecies.data.mangroveHealth}</strong>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
